package org.sudu.experiments.editor; 
// sinle line comment 
public class QQ { 
  public static void main(String[] args) { 
    System.out.println("args = " + args)  
  } 
} 
